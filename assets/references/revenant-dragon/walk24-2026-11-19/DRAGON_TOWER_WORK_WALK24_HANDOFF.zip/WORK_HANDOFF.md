# DRAGON TOWER — Work 작업 인수인계: 망령룡 WALK 24프레임 적용

## 작업 목적
사용자가 승인한 **24_FRAME_COMPAT_REPLACE_18** 버전을 현재 게임의 **망령룡 `move` 애니메이션**에 실제 적용하고 검증한다. 17.5 보조 포즈로 기존 18번을 대체한 24프레임 버전이다. **25프레임 버전을 쓰지 않는다.**

## GitHub / 순서 (2026-11-19 조회)
- 대상: https://github.com/1rkdwnsgh1/dragon-tower
- 시작할 때 `docs/STATE.md`, `docs/INDEX.md`부터 읽고, 관련 문서 `assets/dragons/README.md`, `docs/character-pipeline.md` 4장, `docs/quality-tools.md` 5장, `docs/decisions.md`, `assets/dragons/revenant/dragon.txt`를 확인한다.
- 공식 `docs/STATE.md`: **main 직접 커밋 금지 → 작업 브랜치 + PR**, 팀원의 소스 수정 담당일과 겹치면 임의 소스 수정 금지. 이번 작업은 에셋 교체를 우선하고 소스 수정은 필요할 때만 해당 규칙에 맞춘다.
- 공식 문서 기준 런타임 스프라이트는 **오른쪽 지향, 단일 가로줄, 셀 256×256, 발 기준 (128,240)**이다. 본 ZIP의 원본은 **왼쪽 지향, 1024×1024 개별 프레임, 6×4 원본 시트**이므로 시트를 직접 `move.png`로 복사하면 안 된다.
- 현재 런타임: `assets/dragons/revenant/move.png` 및 `assets/dragons/revenant/dragon.txt` `[anim.move]`(기존 fps=8, frame_w=256, render_scale=1.13, loop=yes). 소스 최신 상태에서 확인하고 기존 값은 임의 변경하지 말 것.

## 입력 에셋
- `source/frames/REVENANT_WALK_01.png` ~ `REVENANT_WALK_24.png`: 24장, 각 1024×1024 RGBA.
- `source/REVENANT_WALK_SPRITESHEET.png`: 6144×4096, **작업용 시트**로만 참고.
- `source/REVENANT_WALK_PREVIEW.gif`, `source/REVENANT_WALK_PREVIEW_SLOW.gif`: 비교 재생용.
- `SOURCE_MANIFEST.json`: 파일 SHA-256 / 규격 검증 기록.
- 원본 V7 패키지의 25프레임 버전은 포함하지 않았다.

## 실행 순서
1. 최신 저장소를 확인하고 기존 `assets/dragons/revenant/move.png` 및 `dragon.txt`를 백업하거나 Git으로 복구 가능하도록 기준 커밋을 기록한다. 다른 드래곤/스킬/UI는 건드리지 않는다.
2. `source/frames`의 파일명 순서를 01~24로 고정하고 실제 원본에 모두 알파가 있는지 확인한다. 원본의 정렬과 프레임 간 상대 움직임을 유지한다. 특히 새 **18번**이 17.5 보조 자세라는 점을 지킨다.
3. 저장소의 `tools/make_sheet.py`와 `docs/known-issues.md`에 적힌 시트 변환 주의사항을 읽고, **`--mirror`로 왼쪽→오른쪽** 반전, 256×256 셀 및 가로 24칸으로 변환한다. `--align union` 또는 동등한 일괄 정렬을 우선 고려해 프레임마다 재중심 정렬/리사이즈로 보행이 튀지 않게 한다. 현행 원본을 변경하지 않는다.
4. 변환한 파일을 `assets/dragons/revenant/move.png`로 적용한다. 기대 형식은 **6144×256 RGBA, 가로 24칸**이지만 실제 도구와 런타임 형식을 먼저 점검한다. 발 기준 (128,240), 몸 크기와 IDLE 전환 시 크기 일관성을 확인한다.
5. `dragon.txt` `[anim.move]`에서 `frame_w=256`, `loop=yes` 및 `fps=8`가 현행 설정과 일치하는지 확인한다. 기존 fps=8이면 24프레임 루프 3초; 속도 변경은 실제 게임에서 보고 필요할 때만 변경하며 이유를 기록한다. `render_scale=1.13`도 새 시트의 체형 크기에 맞는지 검토하되 임의 튜닝하지 않는다.
6. `tools/check_sheets.py` 또는 `docs/quality-tools.md` 규격 검사를 수행하고, `asset_check` 등 게임 에셋 검사 및 해당 테스트/빌드를 실행한다. Windows GUI 직접 확인이 불가능하다면 미검증으로 남기고 사용자를 위한 Windows 체크 절차를 남긴다.
7. 특히 17→18→19, 24→01, 발 접지·교차, 좌우 반전, IDLE↔MOVE 전환, 기존 8프레임 대비 속도, 120px 표시 시 선명도를 확인한다. 수정 범위와 잔여 문제를 QA 문서에 기록한다. 18번 교체로 기존 동작이 튈 수 있으며 **이미지 QA는 NEEDS_REVIEW** 상태임을 숨기지 않는다.
8. `docs/STATE.md` 및 필요한 망령룡 진행 기록을 동일 PR에서 갱신한다. 관련 없는 작업을 건드리지 말고, 브랜치/PR 링크, 변경 파일 목록, 검사 결과, Windows 미검증 항목을 보고한다.

## 완료 기준
- 게임용 `move.png`가 24프레임으로 로딩됨
- 다른 드래곤·스킬 에셋 불변
- 기존 프레임/설정 백업 또는 Git 이력으로 복원 가능
- 정적 검사 및 빌드 결과 명시
- 게임 실제 확인 불가 시 '적용 완료'와 'Windows 재생 검수 완료'를 구분
- main 직접 커밋 금지; 브랜치와 PR 준수
