# 골각 사출 PROJECTILE FX V1

작업 ID **AWAKENED-BONE-SHOT-PROJECTILE-V1**  
비행 에셋 검수 **PASS** · 사용자 승인 대기

| 파일 | 용도 |
|---|---|
| PROJECTILE_MASTER.png | 고정 골각, 768×768 RGBA. 선단은 왼쪽 |
| source/PROJECTILE_BONE_ART.png | 승인 마스터의 재료와 관통 시안을 참고한 고해상도 골각 원화, 2068×455 RGBA |
| frames/PROJECTILE_000.png–015.png | 768×768 RGBA 합성 프레임, 제자리 비행 루프 |
| layers/L1_BONE · L2_MAIN_TRAIL · L3_PARTICLES | 각각 16장, 합성 프레임과 같은 캔버스와 좌표. 합성 순서는 L2 → L3 → L1 |
| PROJECTILE_V1_SHEET.png | 768×768 셀 16개 가로 배치, 12288×768 RGBA |
| PROJECTILE_GAME_256.png | 256×256 셀 16개 가로 배치, 4096×256 RGBA. 왼쪽 방향, 앵커 (128, 128), 오른쪽 사용 시 좌우 반전 |
| PROJECTILE_V1.gif | 투명 미리보기, 16프레임·16 FPS 기준·1초 무한 반복. GIF는 알파가 이진화되며 PNG는 부드러운 알파를 보존 |
| BODY_PROJECTILE_PREVIEW.gif | BODY V2와 합성한 발사 방향·시점 검수용 예시 |
| PROJECTILE_TIMING.json · QA_GAME_SIZE.png | 프레임 간격·앵커와 156px·96px 표시 검수 |

## 시각·기술 검수

- 상아색 골질, 짙은 음영, 골극과 구멍, 뾰족한 왼쪽 선단이 구분됩니다. 16장 모두 L1이 픽셀 단위로 동일하며, 불투명한 골격의 색·선단·크기·좌표가 합성본에서도 고정됩니다.
- L2의 가는 청록색 리본은 골각 뒤로 흐르고 L3의 작은 입자가 뒤에서 나타났다 흐려집니다. 모든 합성 프레임이 서로 다르며 3개 레이어 재합성과 두 스프라이트 시트의 셀 일치도 확인했습니다.
- Qt 재생기로 정상·60% 속도에서 각각 두 바퀴를 재생해 F15→F00의 잔상 연결을 확인했습니다. 배경 위에 합성한 뒤쪽 잔상 영역의 평균 RGB 변화량은 경계에서 3.904/255, 루프 내부 최댓값은 4.455/255였습니다.
- 표시 타일 156px에서 골각이 약 67px 길이로 보입니다. 96px에서는 골각이 약 41px이며 상아색 선단과 청록색 잔상이 구분됩니다. 작은 표시에서는 미세 균열과 입자 일부가 자연스럽게 약해집니다.
- 비행 루프 중 골각이 손실되는 프레임이 없어서 관통 전후에 같은 시트를 이어서 쓸 수 있습니다. 위치 이동과 궤적은 통합 단계에서 처리하는 값입니다.

## BODY V2 연결

- BODY V2 **F07(8번째, 437.5ms)**에서 왼쪽으로 발사하는 예시를 실제 재생했습니다. GIF 표시 간격 기준으로는 440ms입니다.
- 합성 예시의 이마 좌표는 BODY V2의 눈 위치를 기준으로 잡은 **(218.38, 247.47)**입니다. 실제 발사 앵커·표시 배율·이동 속도와 공용 공격의 재생 유지 시간은 게임 통합 단계에서 확인할 값입니다.

[GitHub 캐릭터 파이프라인](https://github.com/1rkdwnsgh1/dragon-tower/blob/main/docs/character-pipeline.md) · [스프라이트 검사](https://github.com/1rkdwnsgh1/dragon-tower/blob/main/docs/quality-tools.md)
